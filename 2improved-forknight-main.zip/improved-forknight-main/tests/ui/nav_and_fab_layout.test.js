const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');
const { JSDOM } = require('jsdom');

const root = path.resolve(__dirname, '..', '..');

// Ensure FAB container positioning

test('fab container fixed to viewport corner', () => {
  const css = fs.readFileSync(path.join(root, 'fabs', 'css', 'cojoin.css'), 'utf-8');
  const match = css.match(/\.fab-container\s*{[\s\S]*?}/);
  assert.ok(match, 'fab-container styles not found');
  const block = match[0];
  assert.ok(/position:\s*fixed/.test(block), 'fab container should be fixed');
  assert.ok(/bottom:\s*20px/.test(block), 'fab container should be 20px from bottom');
  assert.ok(/right:\s*15px/.test(block), 'fab container should be 15px from right');
});

test('nav toggles align with fab margins', () => {
  const css = fs.readFileSync(path.join(root, 'css', 'style.css'), 'utf-8');
  const match = css.match(/@media\s*\(max-width:\s*768px\)[\s\S]*?\.toggles\s*{[\s\S]*?}/);
  assert.ok(match, 'mobile toggles styles not found');
  const block = match[0];
  assert.ok(/right:\s*var\(--space-sm\)/.test(block), 'toggles should use space-sm variable for right positioning');
  assert.ok(/bottom:\s*var\(--space-sm\)/.test(block), 'toggles should use space-sm variable for bottom positioning');
  assert.ok(/margin:\s*0/.test(block), 'toggles should have zero margin');
  assert.ok(/padding:\s*0/.test(block), 'toggles should have zero padding');

  const navToggleMatch = css.match(/@media\s*\(max-width:\s*768px\)[\s\S]*?\.nav-menu-toggle\s*{[\s\S]*?}/);
  assert.ok(navToggleMatch, 'mobile nav-menu-toggle styles not found');
  const navBlock = navToggleMatch[0];
  assert.ok(/margin:\s*0/.test(navBlock), 'nav-menu-toggle should have zero margin');
});

// Ensure clicking outside or on backdrop closes mobile menu

test('mobile menu closes on backdrop or outside click', async () => {
  const html = `<!DOCTYPE html><html><body>
    <nav class="ops-nav">
      <a href="#" class="ops-logo">OPS</a>
      <div class="nav-links" id="primary-nav">
        <a href="#" class="nav-link">Home</a>
      </div>
      <div class="toggles">
        <button type="button" class="toggle-btn lang-toggle">EN</button>
        <button type="button" class="toggle-btn theme-toggle">Dark</button>
        <button type="button" class="toggle-btn nav-menu-toggle" aria-expanded="false" aria-controls="primary-nav" aria-label="" data-aria-label-key="aria-nav-menu">
          <i class="fa-solid fa-bars"></i><span class="sr-only">Menu</span>
        </button>
      </div>
    </nav>
    <div class="nav-backdrop" hidden></div>
  </body></html>`;

  const dom = new JSDOM(html, { runScripts: 'dangerously', url: 'http://localhost' });
  const { window } = dom;
  window.translations = { services: {} };
  window.currentLanguage = 'en';
  window.fetch = async () => ({ json: async () => ({ token: 'test' }) });
  Object.defineProperty(window, 'innerWidth', { value: 500, configurable: true });

  const script = fs.readFileSync(path.join(root, 'js', 'main.js'), 'utf-8');
  window.eval(script);
  // The DOMContentLoaded handler in main.js executes immediately
  // in this test environment because the document is already loaded.
  await new Promise(r => setImmediate(r));

  const toggle = window.document.querySelector('.nav-menu-toggle');
  const navLinks = window.document.querySelector('.nav-links');
  const backdrop = window.document.querySelector('.nav-backdrop');
  const icon = toggle.querySelector('i');

  // Open menu with a normal bubbling click
  toggle.dispatchEvent(new window.MouseEvent('click', { bubbles: true }));
  await new Promise(r => setImmediate(r));
  assert.ok(navLinks.classList.contains('open'), 'menu should open');
  assert.ok(backdrop.classList.contains('open'), 'backdrop should be visible when menu opens');
  assert.ok(icon.classList.contains('fa-xmark'), 'icon should change to xmark when menu opens');

  // Close via backdrop click
  backdrop.dispatchEvent(new window.MouseEvent('click', { bubbles: true }));
  assert.ok(!navLinks.classList.contains('open'), 'menu should close on backdrop click');
  assert.ok(icon.classList.contains('fa-bars'), 'icon should revert to bars when menu closes');

  // Reopen and close via Escape key
  toggle.dispatchEvent(new window.MouseEvent('click', { bubbles: true }));
  await new Promise(r => setImmediate(r));
  assert.ok(navLinks.classList.contains('open'), 'menu should reopen');
  window.document.dispatchEvent(new window.KeyboardEvent('keydown', { key: 'Escape' }));
  assert.ok(!navLinks.classList.contains('open'), 'menu should close on ESC key');

  // Reopen and close via outside click
  toggle.dispatchEvent(new window.MouseEvent('click', { bubbles: true }));
  await new Promise(r => setImmediate(r));
  assert.ok(navLinks.classList.contains('open'), 'menu should open again');
  window.document.body.dispatchEvent(new window.MouseEvent('click', { bubbles: true }));
  assert.ok(!navLinks.classList.contains('open'), 'menu should close on outside click');
  assert.ok(icon.classList.contains('fa-bars'), 'icon should revert to bars after outside click close');
});
